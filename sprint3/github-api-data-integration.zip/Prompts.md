# 📓 Prompts.md — Sprint Learning Log

This file documents the AI prompts I used as a pair-programmer during Sprint 03 (Dev-Detective).
Per sprint guidance, Prompts.md acts as evidence of learning and problem-solving process.

---

## 🎯 Sprint 03 — Dev-Detective (GitHub API Integration)

### Prompt 1 — Understanding Async/Await
> "Explain async/await in JavaScript line by line with a real example using fetch(). Compare it to Promise.then() and show when each is better. I am preparing for a sprint that integrates the GitHub REST API."

**Why:** The sprint FAQ #1 flagged async/await as the steepest learning curve. This prompt ensured I understood the mental model before writing any network code.

---

### Prompt 2 — GitHub REST API Authentication & Rate Limits
> "Explain GitHub REST API rate limits for unauthenticated vs authenticated requests. Show how to attach a Personal Access Token in fetch() headers and why 403 errors occur. What is the best way to handle them in the UI?"

**Why:** Sprint FAQ #3 warned about 60 req/hour limits. I needed to understand why my app might break mid-demo and how to gracefully surface the error.

---

### Prompt 3 — Reducing Total Stars Across Repos
> "Given an array of GitHub repository objects, write a JavaScript function using reduce() to compute the total stargazers_count. Explain each step as if I'm reviewing this in a code review."

**Why:** Sprint FAQ #4 explicitly asked this. I wanted a clean, reviewable accumulator pattern I could explain confidently.

---

### Prompt 4 — Promise.all for Parallel Fetches
> "I need to fetch two GitHub users' profiles AND their repos in parallel using Promise.all(). Show the cleanest pattern, and explain how errors propagate if one of the four fetches fails. Should I wrap each user's pair in its own try/catch or let Promise.all reject on first error?"

**Why:** Battle Mode requires parallel fetches. I needed to decide the error strategy upfront (reject fast vs settle). I chose **reject fast** — if either user is 404, surface that error.

---

### Prompt 5 — XSS Prevention in Vanilla JS Templates
> "When using template literals with innerHTML in vanilla JS, how do I prevent XSS from user-supplied strings? Show a minimal sanitize() function that escapes HTML special characters."

**Why:** GitHub usernames, bios, and repo descriptions are attacker-controlled. Rule #11 required sanitization.

---

### Prompt 6 — Accessible Form Validation
> "Show me an accessible inline form validation pattern for a text input. Include aria-invalid, aria-describedby, role=alert, and keyboard behavior. Don't use any framework."

**Why:** Rule #12 demanded proper accessibility. I wanted to validate inputs without relying on browser-native `:invalid` styling alone.

---

### Prompt 7 — CSS Design Tokens from GitHub's Primer
> "List the key color tokens, border radii, and font stacks from GitHub's Primer design system (dark theme). I want my app to look like github.com without copying their code."

**Why:** Rule #4 required a GitHub-inspired look. Primer tokens gave me a professional, consistent palette.

---

### Prompt 8 — ES Modules vs Classic Scripts
> "I am building a vanilla JS project with separate files: utils.js, api.js, ui.js, script.js. Should I use type=module or classic scripts with globals? Explain the pros and cons for a code review audience."

**Why:** Rule #19 emphasized reviewability. ES Modules give clear imports/exports, no global pollution, and a dependency graph that's easy to explain.

---

### Prompt 9 — State Machine for a Search UI
> "Design a minimal state machine for a search UI with states: idle, validating, loading, success, error, not-found. Show how to represent it in vanilla JS and render each state into the DOM."

**Why:** I wanted to avoid "if/else soup" and structure the app around explicit states. This led to the clear `showLoading / showError / renderProfile` separation in `ui.js`.

---

### Prompt 10 — Code Review Self-Check
> "Act as a senior frontend engineer. Review this architecture: utils.js (pure helpers), api.js (fetch layer), ui.js (render layer), script.js (orchestrator). Identify code smells, missing edge cases, and improvements I should make before a production review."

**Why:** Rule #18 required a senior-level review. This prompt surfaced issues I then fixed (e.g., adding `encodeURIComponent` on usernames, handling missing avatars, `prefers-reduced-motion` in CSS).

---

## 🧠 Key Takeaways

1. **Separation of concerns pays off.** Having `api.js` independent from `ui.js` meant I could test the network layer in the console without touching the DOM.
2. **Async/Await is clearer than `.then()` chains** for sequential fetches (user → repos), but `Promise.all()` is unbeatable for parallel work (Battle Mode).
3. **Typed errors (ApiError with `.code`)** made the UI layer trivial — it just switches on `err.code`.
4. **Sanitize at render time, not fetch time.** API data should stay pristine; escaping belongs in the template layer.
5. **Validate early, fail visibly.** Silent failures are the #1 bug in junior code. Every invalid state now has a visible UI.
6. **Design tokens beat ad-hoc colors.** Primer's CSS variables made the entire theme consistent and easy to tweak.

---

## 📌 Registered Email (Employee Identifier)

> *(Replace with your registered email address for QA submission)*

---

*Last updated during Sprint 03.*
