# 🕵️ Dev-Detective · GitHub Profile Explorer

A production-quality **vanilla JavaScript** single-page application that consumes the **GitHub REST API** to explore developer profiles and run side-by-side comparisons.

Built as a sprint deliverable to demonstrate **Fetch API**, **Promises**, **Async/Await**, and **Promise.all()** — before transitioning to React.

---

## 🎯 Sprint Phases & Requirements

### Phase 1 — Base MVP (P0) ✅
| Requirement | Status | Location |
|---|---|---|
| Search input + Profile Card | ✅ | `ui.js` → `renderProfile` |
| Async GET to `/users/{username}` | ✅ | `api.js` → `fetchUser` |
| Render Avatar, Name, Bio, Join Date, Portfolio | ✅ | `ui.js` |
| Loading State (spinner) | ✅ | `ui.js` → `showLoading` |
| Error Handling (404 "User Not Found") | ✅ | `ui.js` → `showError('NOT_FOUND')` |

### Phase 2 — Data Expansion (P1) ✅
| Requirement | Status | Location |
|---|---|---|
| Chained `repos_url` fetch | ✅ | `api.js` → `fetchUserWithRepos` |
| Top 5 latest repositories | ✅ | `ui.js` → `renderProfile` slices first 5 |
| Clickable `<a href>` repo links (new tab) | ✅ | `repo-list` markup |
| ISO → readable date utility | ✅ | `utils.js` → `formatDate` |

### Phase 3 — Battle Mode (P2) ✅
| Requirement | Status | Location |
|---|---|---|
| Toggle reveals dual-input UI | ✅ | `script.js` → `updateMode` |
| Two simultaneous fetches via `Promise.all()` | ✅ | `api.js` → `fetchBattlePair` |
| Total Stars calculation via `reduce()` | ✅ | `utils.js` → `totalStars` |
| Conditional Winner/Loser UI (green/red) | ✅ | `ui.js` → `renderBattle` |

---

## 📂 Project Architecture

```
dev-detective/
├── index.html    # Semantic structure + accessibility tree
├── style.css     # GitHub-inspired design system (CSS variables)
├── script.js     # Orchestrator: events, state, wiring
├── api.js        # Network layer: fetch wrappers, typed errors
├── ui.js         # View layer: DOM rendering, templates
├── utils.js      # Pure helpers: date, sanitize, validate
├── README.md     # This file
└── Prompts.md    # Sprint prompts & learning log
```

**One-way dependency graph:**
```
script.js ─► api.js ─► utils.js
    │         │
    └───────► ui.js ─► utils.js
```

---

## 🚀 How to Run

Because this project uses **ES Modules** (`type="module"`), you must serve it over HTTP (not `file://`).

### Option 1 — VS Code Live Server (recommended)
1. Install the **Live Server** extension.
2. Right-click `index.html` → *Open with Live Server*.

### Option 2 — Python
```bash
python -m http.server 5500
```
Then visit `http://localhost:5500`.

### Option 3 — Node
```bash
npx serve .
```

---

## 🔑 API Rate Limit

GitHub allows **60 unauthenticated requests/hour**. If you hit the 403 limit:

1. Go to GitHub → **Settings → Developer Settings → Personal Access Tokens → Tokens (classic)**.
2. Generate a token with `public_repo` scope.
3. Optionally add to `api.js` headers:
   ```js
   headers: { Authorization: 'Bearer YOUR_TOKEN' }
   ```
   This raises the limit to **5,000 requests/hour**.

---

## 🧩 Key Functions

| Function | File | Purpose |
|---|---|---|
| `fetchUser(username)` | `api.js` | GET user profile |
| `fetchRepos(username)` | `api.js` | GET user repos (sorted by updated) |
| `fetchUserWithRepos(username)` | `api.js` | Combined profile + repos |
| `fetchBattlePair(a, b)` | `api.js` | `Promise.all()` for dual fetch |
| `formatDate(iso)` | `utils.js` | ISO → "25 Jan 2023" |
| `validateUsername(str)` | `utils.js` | Client-side validation |
| `sanitize(str)` | `utils.js` | XSS prevention |
| `totalStars(repos)` | `utils.js` | `reduce()` on `stargazers_count` |
| `renderProfile(data)` | `ui.js` | Profile + top-5 repos DOM |
| `renderBattle(data)` | `ui.js` | Battle cards + verdict |
| `showLoading/showError/showEmpty` | `ui.js` | State rendering |

---

## ♿ Accessibility

- Semantic HTML (`<header>`, `<main>`, `<article>`, `<section>`, `<footer>`).
- Visible `<label>` for every input.
- `aria-live="polite"` on the result area for screen reader updates.
- `role="alert"` on errors, `role="status"` on loading.
- `aria-invalid` + `aria-describedby` on inputs for validation.
- Full keyboard navigation (Enter to submit, Space/Enter to toggle mode).
- `:focus-visible` outlines on all interactive elements.
- `prefers-reduced-motion` support.
- Screen-reader-only text for icon-only controls.

---

## 🛡️ Edge Cases Handled

- ✅ Empty input → visible inline validation
- ✅ Invalid username format → inline error + alert
- ✅ 404 Not Found → dedicated error UI
- ✅ 403 Rate limit → dedicated error UI with guidance
- ✅ Network failure (offline) → retry prompt
- ✅ Malformed JSON → graceful fallback
- ✅ Missing avatar → fallback placeholder
- ✅ Missing bio → "No bio provided"
- ✅ Missing blog/portfolio → field hidden
- ✅ Zero repos → "No public repositories yet"
- ✅ Same username in Battle Mode → validation error

---

## 🧪 Testing the QA Demo Video Checklist

For the 2-minute QA demo, demonstrate in order:

1. Empty state on initial load.
2. Valid search (e.g., `octocat`) → loading spinner → profile renders.
3. Invalid search (e.g., `this_user_does_not_exist_xyz`) → 404 error UI.
4. Toggle Battle Mode.
5. Two valid users → winner/loser comparison renders.
6. Same username in both fields → validation error.

---

## 📚 Tech Stack

- **HTML5** (semantic, accessible)
- **CSS3** (custom properties, grid, flexbox)
- **Vanilla JavaScript** (ES Modules)
- **Native Fetch API**
- **Async/Await**
- **Promise.all()**
- **GitHub REST API v3**

**Not used (per sprint rules):** React, frameworks, Axios, jQuery, build tools.

---

## 📝 License

Built for educational sprint evaluation. Free to use and adapt.
